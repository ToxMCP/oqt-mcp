# Hazard Summary: Acetaminophen

Acetaminophen shows hepatotoxicity signals at high doses. Experimental data supports a medium-confidence assessment.